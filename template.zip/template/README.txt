Project group number: 84
Group member names and x500s: 
	Justin Pederson: pede0831@umn.edu
	Chiemeka Nwakama: nwaka013@umn.edu
	Ibrahim Ismail-Adebiyi: ismai128@umn.edu
CSELabs computer the code was tested on: csel-kh1250-01.cselabs.umn.edu //Finish this
There were no changes made to the Makefile or existing files that weren’t supposed to be changed.
Planned outlining individual contributions:
	Justin: child_process.c
	Chiemeka: utils.c
	Ibrahim: merkle.c
We decided to spilt the PA1 up depending on the different files and this is how we spilt them up.
Plan on how process tree component of creating the Merkle tree: //Finish this
